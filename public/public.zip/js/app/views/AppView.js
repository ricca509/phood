define(['backbone'], function(Backbone) {
    var View = Backbone.View.extend({
        initialize: function() {
            console.log('AppView loading...');
        }
    });

    return View;
});