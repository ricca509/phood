define({
	appName: 'Yummly'	
});